<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	include 'sessioncontrol.php';
	require 'dbconn.php';
	require 'courses.php';
	require 'userservice.php';
	
	$courseinfo = New courses;
	$userauth = New UserService($_SESSION['username'],0);
	$sendtoDB = New DBConn;
	$del = 0;

	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	    if (isset($_POST["waitinglistid"])){
	        // Build sql syntax
	        $sqlselect=$courseinfo->removewl($_POST['waitinglistid']);
	        $userdata = $sendtoDB->executeSelectQuery($sqlselect);
	        $del = 1 ;    
	    }
	}
	// Build sql syntax
	$sqlselect=$userauth->userdataSQL($_SESSION['id']);
	$userdata = $sendtoDB->executeSelectQuery($sqlselect);
	$sqlselect=$courseinfo->userwl($_SESSION['id']);
	$wldata = $sendtoDB->executeSelectQuery($sqlselect);
	
	$svalue = mysqli_num_rows($wldata);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        table{
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Current Courses in the Waiting List</h1>
	</div>
	<br><br>
	<div class="container text-center">
	<h2>
<?php 
if (mysqli_num_rows($userdata)){
    $row = $userdata->fetch_assoc();
    echo "Student ID:" .$row['userid'] . "<br>";
    echo "First Name:" . $row['firstName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp ";
    echo "Last Name:" . $row['lastName'] . "";
}
?>
</h2></div><br>	

	<table class="table table-striped">
<?php
if ($del == 1){echo "<div class='container text-center'><h2>You have release your waiting list position</h2></div>";}
if ($svalue==0){
    echo "<tr><th class='text-center'>No waiting list found</th></tr>";
} else {

    if (mysqli_num_rows($wldata)){
        echo "<form class='form-horizontal' method='post' action='".$_SERVER["PHP_SELF"] ."'>";
        echo "<tr><th class='text-center'>Class Code</th><th class='text-center'>Description</th><th class='text-center'>Semester</th><th class='text-center'>Credits</th><th class='text-center'>Position</th></tr>";
        while ($row = $wldata->fetch_assoc()){
	    echo "<tr><td class='text-left'><label><input type='radio' name='waitinglistid' value='" .$row['waitinglistid'] . "' required='required'> " .$row['coursecode'] ."</label></td>";
	    echo "<td class='text-center'>" .$row['description'] . "</td><td class='text-center'>" .$row['semestercode'] . "</td>";
	    echo "<td class='text-center'>" .$row['credits'] . "</td>";
	    echo "<td class='text-center'>" .$row['position'] . "</td></tr>";
        }
        echo "<td class='text-center' colspan='5'><button type='submit' class='btn btn-warning'>Unregister from course</button></td>";

    }
}
?>
	
	</table><br>	<div class="text-center">
	<a class="btn btn-primary" href="index.php?Logout=1" role="button">Logout </a>
	</div><br><br><br>
<?php require 'footer.php';?>
</body>
</html>