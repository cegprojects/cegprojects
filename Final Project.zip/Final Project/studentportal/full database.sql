--
-- Database: `student_portal`
--
CREATE DATABASE `student_portal` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `student_portal`;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

CREATE TABLE `tbluser` (
  `userid` int(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `firstName` varchar(25) NOT NULL,
  `lastName` varchar(25) NOT NULL,
  `address` varchar(25) NOT NULL,
  `city` varchar(15) NOT NULL,
  `usstate` varchar(15) NOT NULL,
  `zipcode` int(5) NOT NULL,
  `phone` bigint(15) NOT NULL,
  `mayor` varchar(25) NOT NULL,
  `accessid` int(10) DEFAULT 100
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tbluser`
  ADD PRIMARY KEY (`userid`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tbluser`
  MODIFY `userid` int(10) NOT NULL AUTO_INCREMENT;
  
  CREATE TABLE `tblcourse` (
  `courseid` int(10) NOT NULL,
  `coursecode` varchar(10) NOT NULL,
  `credits` int(10) DEFAULT 3,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tblcourse`
  ADD PRIMARY KEY (`courseid`),
  ADD UNIQUE KEY `coursecode` (`coursecode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tblcourse`
  MODIFY `courseid` int(10) NOT NULL AUTO_INCREMENT;
  
  CREATE TABLE `tblsemester` (
  `semesterid` int(10) NOT NULL,
  `semestercode` varchar(10) NOT NULL,
  `description` varchar(50) NOT NULL,
  `startdate` DATE NOT NULL,
  `enddate` DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tblsemester`
  ADD PRIMARY KEY (`semesterid`),
  ADD UNIQUE KEY `semestercode` (`semestercode`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbluser`
--
ALTER TABLE `tblsemester`
  MODIFY `semesterid` int(10) NOT NULL AUTO_INCREMENT;
  
CREATE TABLE `tblcoursesemester` (
  `semesterid` int(10) NOT NULL,
  `courseid` int(10) NOT NULL,
  `maxstudents` int(10) NOT NULL,
  `teacher` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tblcoursesemester`
  ADD PRIMARY KEY (`semesterid`, `courseid`);
  
  CREATE TABLE `tblstudenthistory` (
  `shistoryid` int(10) NOT NULL,
  `courseid` int(10) NOT NULL,
  `semesterid` int(10) NOT NULL,
  `studentid` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tblstudenthistory`
  ADD PRIMARY KEY (`shistoryid`);


ALTER TABLE `tblstudenthistory`
  MODIFY `shistoryid` int(10) NOT NULL AUTO_INCREMENT;
  
  CREATE TABLE `tblaccesscontrol` (
  `accessid` int(10) NOT NULL,
  `accesscode` varchar(10) NOT NULL,
  `description` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for table `tbluser`
--
ALTER TABLE `tblaccesscontrol`
  ADD PRIMARY KEY (`accessid`);


USE `student_portal`;

--
-- Insert Access levels
--
INSERT INTO `tblaccesscontrol` (`accessid`, `accesscode`, `description`) VALUES ('100', 'STUDENT', 'Access for Students');
INSERT INTO `tblaccesscontrol` (`accessid`, `accesscode`, `description`) VALUES ('200', 'PROFESSOR', 'Access for Professor');
INSERT INTO `tblaccesscontrol` (`accessid`, `accesscode`, `description`) VALUES ('300', 'FACULTY', 'Access for Faculty');
INSERT INTO `tblaccesscontrol` (`accessid`, `accesscode`, `description`) VALUES ('999', 'ADMIN', 'Access for Administrators');

--
-- Insert Courses

INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('101', 'ENG121', '3', 'ENGLISH COMPOSITION I');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('102', 'PHI103', '3', 'INFORMAL LOGIC');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('103', 'MAC1105', '3', 'COLL ALGEBRA');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('104', 'ANT101', '3', 'INTRODUCTION TO CULTURAL ANTHROPOLOGY');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('105', 'ENG225', '3', 'INTRODUCTION TO FILM');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('106', 'SCI207', '4', 'OUR DEPENDENCE UPON THE ENVIRONMENT');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('107', 'BUS202', '3', 'PROFESSIONAL & BUSINESS COMMUNICATIONS');
INSERT INTO `tblcourse` (`courseid`, `coursecode`, `credits`, `description`) VALUES ('108', 'TMG300', '3', 'SCRUM BASICS');

--
-- Insert Semester
--
INSERT INTO `tblsemester` (`semesterid`, `semestercode`, `description`, `startdate`, `enddate`) VALUES ('201', 'SUMMER2024', 'Summer Semester 2024', '2024-05-13', '2024-08-02');
INSERT INTO `tblsemester` (`semesterid`, `semestercode`, `description`, `startdate`, `enddate`) VALUES ('202', 'FALL2024', 'Fall Semester 2024', '2024-08-26', '2024-12-12');
INSERT INTO `tblsemester` (`semesterid`, `semestercode`, `description`, `startdate`, `enddate`) VALUES ('203', 'SPRING2024', 'Spring Semester 2025', '2025-01-13', '2025-05-08');
INSERT INTO `tblsemester` (`semesterid`, `semestercode`, `description`, `startdate`, `enddate`) VALUES ('204', 'SUMMER2025', 'Summer Semester 2025', '2025-05-19', '2025-08-08');


--
-- Insert Students
--
INSERT INTO `tbluser` (`userid`, `email`, `password`, `firstName`, `lastName`, `address`, `city`, `usstate`, `zipcode`, `phone`, `mayor`, `accessid`) 
VALUES (NULL, 'carmelo.gonzalez@uagc.com', 'Welcome1!', 'Carmelo', 'Gonzalez', '123 Main Street', 'Miami', 'FL', '12345', '0123456789', 'Computer Programming', '100');
INSERT INTO `tbluser` (`userid`, `email`, `password`, `firstName`, `lastName`, `address`, `city`, `usstate`, `zipcode`, `phone`, `mayor`, `accessid`) 
VALUES (NULL, 'john.doe@uagc.com', 'Welcome1!', 'John', 'Doe', '123 Main Street', 'Miami', 'FL', '12345', '0123456789', 'Cybersecurity', '100');



--
-- Insert Course and Semester 
--
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('201', '101','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('201', '102','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('201', '103','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('201', '104','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('201', '105','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('202', '101','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('202', '108','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('202', '107','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('202', '106','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('202', '105','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('203', '101','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('203', '102','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('203', '103','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('203', '104','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('203', '105','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('204', '101','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('204', '108','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('204', '107','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('204', '106','5', 'John Doe');
INSERT INTO `tblcoursesemester` (`semesterid`, `courseid`,`maxstudents`, `teacher`) VALUES ('204', '105','5', 'John Doe');