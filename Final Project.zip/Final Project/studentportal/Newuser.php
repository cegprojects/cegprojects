<?php

// Creating class for New User
Class Newuser{
	Private $firstName;
	Private $lastName;
	Private $email;
	Private $password;
	Private $cpassword;
	Private $address;
	Private $city;
	Private $state;
	Private $zipcode;
	Private $phone;
	Private $err;
	
	function __construct($firstName, $lastName, $email, $password, $cpassword, $address, $city, $state, $zipcode, $phone){
		$this->setFirstName($firstName);
		$this->setLastName($lastName);
		$this->setEmail($email);
		$this->setPassword($password);
		$this->setCpassword($cpassword);
		$this->setAddress($address);
		$this->setCity($city);
		$this->setState($state);
		$this->setZipcode($zipcode);
		$this->setPhone($phone);
		$this->setERR(0);
	}
	
	// Get functions
	
	public function getFirstName() {
		return $this->firstName;
	}
	public function getLastName() {
		return $this->lastName;
	}
	public function getEmail() {
		return $this->email;
	}
	public function getPassword() {
		return $this->password;
	}
	public function getCpassword() {
		return $this->cpassword;
	}
	public function getAddress() {
		return $this->address;
	}
	public function getCity() {
		return $this->city;
	}
	public function getState() {
		return $this->state;
	}
	public function getZipcode() {
	    return $this->zipcode;
	}
	public function getPhone() {
	    return $this->phone;
	}
	public function getERR() {
	    return $this->err;
	}
	
	// Set fucntion
	
	public function setFirstName ($firstName) {
		$this->firstName = $firstName;
	}
	public function setLastName ($lastName) {
		$this->lastName = $lastName;
	}
	public function setEmail ($email) {
		$this->email = $email;
	}
	public function setPassword ($password) {
		$this->password = $password;
	}
	public function setCpassword ($cpassword) {
		$this->cpassword = $cpassword;
	}
	public function setAddress ($address) {
		$this->address = $address;
	}
	public function setCity ($city) {
		$this->city = $city;
	}
	public function setState ($state) {
		$this->state = $state;
	}
	public function setZipcode ($zipcode) {
	    $this->zipcode = $zipcode;
	}
	public function setPhone ($phone) {
	    $this->phone = $phone;
	}
	public function setERR ($err) {
	    $this->err = $err;
	}
	
	// Validate fucntion
	
	public function validateFirstName () {
		$valid = "";
		if (empty($this->firstName)){
		    $this->setERR(1);
			$valid = "<FONT COLOR='RED'>First Name is required</FONT><br>";
		}
		return $valid;
	}
	public function validateLastName () {
		$valid = "";
		if (empty($this->lastName)){
		    $this->setERR(1);
			$valid = "<FONT COLOR='RED'>Last Name is required</FONT><br>";
		}
		return $valid;
	}
	public function validateEmail () {
		$valid = "";
		if (empty($this->email) and filter_var($this->email, FILTER_VALIDATE_EMAIL)){
		    $this->setERR(1);
			$valid = "<FONT COLOR='RED'>Valid Email is required</FONT><br>";
		}
		return $valid;
	}
	public function validatePassword () {
		// Validate password strength
		$valid = "";
		$uppercase = preg_match('@[A-Z]@', $this->password);
		$lowercase = preg_match('@[a-z]@', $this->password);
		$number    = preg_match('@[0-9]@', $this->password);
		$specialChars = preg_match('@[^\w]@', $this->password);
		
		if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($this->password) < 8) {
		    $this->setERR(1);
			$valid = "<FONT COLOR='RED'>Password should be at least 8 characters in length and should include at least one upper case letter, one number, and one special character.</FONT><br>";
		} elseif (!$this->checkPassword()) {
		    $this->setERR(1);
			$valid = "<FONT COLOR='RED'>Password and Confirm Password does not match</FONT><br>";
		}
		return $valid;
	}
	public function validateAddress () {
		//
	}
	public function validateCity () {
		//
	}
	public function validateState () {
		//
	}
	public function validateZipcode () {
	    //
	}
	public function validatePhone () {
	    //
	}
	public function validateALL () {
	    $valid = 1;
	    if ($this->getERR()){
	        $valid = 0;
	    }
		return $valid;
	}
	
	// Other functions
	public function checkPassword(){
		$pass=0;
		if ($this->password==$this->cpassword) {
			$pass=1;
		}
		return $pass;
	}
	public function BuildSQLcheckemail () {
		$SQL = "SELECT email FROM tbluser WHERE email=' $this->email'";
		return $SQL;
	}
	public function BuildSQLInsert () {
	    	$SQL = "INSERT INTO tbluser (email, password, firstName, lastName, address, city, usstate, zipcode, phone) 
			VALUES ('$this->email','$this->password','$this->firstName','$this->lastName','$this->address',
			'$this->city','$this->state','$this->zipcode', '$this->phone');";
		return $SQL;
	}
}

?>
