<?php
	error_reporting(E_ALL ^ E_NOTICE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<div class="navbar-fixed-bottom row-fluid">
	<div class="nav-inner">
		<div class="container text-center">
		&copy; Copyright @ 2024
		</div>
	</div>
</div>

</body>
</html>