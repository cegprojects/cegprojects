<?php
//Checking if session is open or close
ini_set('session.use_only_cookies', '1');
session_start();
$scriptname = basename($_SERVER['PHP_SELF']);

if ($scriptname=="profile.php" AND !isset($_SESSION['id'])) {
    header("location:login.php"); //to redirect back to "index.php"
    exit();
}
if ($scriptname=="mainmenu.php" AND !isset($_SESSION['id'])) {
    header("location:login.php"); //to redirect back to "index.php"
    exit();
}

?>
