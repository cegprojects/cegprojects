<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	include 'sessioncontrol.php';
	require 'dbconn.php';
	require 'courses.php';
	require 'userservice.php';
	
	$courseinfo = New courses;
	//$userauth = New UserService($_SESSION['username'],0);
	$sendtoDB = New DBConn;
	// Build sql syntax
	$sqlselect=$courseinfo->checkcoursemax($_POST['course'],$_SESSION['semester']);
	$checkmax = $sendtoDB->executeSelectQuery($sqlselect);
	$sqlselect=$courseinfo->checkcoursecurrent($_POST['course'],$_SESSION['semester']);
	$checkcurrent = $sendtoDB->executeSelectQuery($sqlselect);
	$sqlselect=$courseinfo->checkrepeatedenroll($_SESSION['id'],$_POST['course'],$_SESSION['semester']);
	$checkrepeated = $sendtoDB->executeSelectQuery($sqlselect);
	
	$coursemax = mysqli_num_rows($checkmax);
	$row = $checkcurrent->fetch_assoc();
	$coursecurrent = $row['maxstudents'];
	$courserepeat = mysqli_num_rows($checkrepeated);
	
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        table{
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Confirm Adding Class</h1>
	</div>
<?php 
if ($courserepeat == 0 AND $coursemax <= $coursecurrent){
    $sqlselect=$courseinfo->enrollcourse($_SESSION['id'],$_POST['course'],$_SESSION['semester']);
    $enroll = $sendtoDB->executeSelectQuery($sqlselect);
    echo "<div class='container text-center'><h3>Class been registered sucessfull<br>";
    echo "<a href='mainmenu.php' type='button' class='btn btn-info'>Main Menu</a></div>";
} else {
    echo "<div class='container text-center'><h3>Class cannot be registered</h1><br>";
    echo "<a href='addcourse.php?semester={$_SESSION['semester']}' type='button' class='btn btn-info'>Go Back</a></div>";
}

?>	

	
	
<br><br><br>
<?php require 'footer.php';?>
</body>
</html>