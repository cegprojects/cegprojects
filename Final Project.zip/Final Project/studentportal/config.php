<?php
define('DBHOST', 'localhost');
define('DBNAME', 'student_portal');
define('DBUSER', 'root');
define('DBPASS', '');
?>
