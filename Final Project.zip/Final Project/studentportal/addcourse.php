<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	include 'sessioncontrol.php';
	require 'dbconn.php';
	require 'courses.php';
	require 'userservice.php';
	
	$courseinfo = New courses;
	$userauth = New UserService($_SESSION['username'],0);
	$sendtoDB = New DBConn;
	// Build sql syntax
	$sqlselect=$courseinfo->listsemester();
	$semesterdata = $sendtoDB->executeSelectQuery($sqlselect);
	$sqlselect=$userauth->userdataSQL($_SESSION['id']);
	$userdata = $sendtoDB->executeSelectQuery($sqlselect);
	
	if(!isset($_GET['semester'])){
	    $svalue = 0;
	} else {
	    $svalue=$_GET['semester'];
	    $_SESSION['semester']=$svalue;
	}
	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        table{
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Current Courses</h1>
	</div>
	<div class="container text-center">
	<h2>
<?php 
if (mysqli_num_rows($userdata)){
    $row = $userdata->fetch_assoc();
    echo "Student ID:" .$row['userid'] . "<br>";
    echo "First Name:" . $row['firstName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp ";
    echo "Last Name:" . $row['lastName'] . "";
}
?>
</h2></div><br>
<!-- Single button -->
<div class="container text-center">
<?php 
if (mysqli_num_rows($semesterdata)){
    while($row = $semesterdata->fetch_assoc()){
        if ($svalue != $row['semesterid'] ){
            echo "<a href='addcourse.php?semester=".$row['semesterid'] . "'type='button' class='btn btn-info'>" .$row['semestercode'] ."</a> ";
        } else {
            echo "<a href='addcourse.php?semester=".$row['semesterid'] . "'type='button' class='btn btn-warning'>" .$row['semestercode'] ."</a> ";
        }          
    }}
?>
</div><br><br>    
	<table class="table table-striped">
<?php
if ($svalue==0){
    echo "<tr><th class='text-center'>Select A Semester</th></tr>";
} else {
    $sqlselect=$courseinfo->listcourses($_SESSION['semester']);
    $coursedata = $sendtoDB->executeSelectQuery($sqlselect);
    if (mysqli_num_rows($coursedata)){
        echo "<form class='form-horizontal' method='post' action='confirmadd.php'>";
        echo "<tr><th class='text-center'>Class Code</th><th class='text-center'>Description</th><th class='text-center'>Teacher</th><th class='text-center'>Credits</th><th class='text-center'>Max Enrollment</th></tr>";
        while ($row = $coursedata->fetch_assoc()){
	    echo "<tr><td class='text-left'><label><input type='radio' name='course' value='" .$row['courseid'] . "' required='required'> " .$row['coursecode'] ."</label></td>";
	    echo "<td class='text-center'>" .$row['description'] . "</td><td class='text-center'>" .$row['teacher'] . "</td>";
	    echo "<td class='text-center'>" .$row['credits'] . "</td><td class='text-center'>" .$row['maxstudents'] . "</td></tr>";
        }
        echo "<td class='text-center' colspan='5'><button type='submit' class='btn btn-primary'>Register for course</button></td>";

    }
}
?>
	
	</table><br>
<br><br><br>
<?php require 'footer.php';?>
</body>
</html>