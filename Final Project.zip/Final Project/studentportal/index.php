<?php
	error_reporting(E_ALL ^ E_NOTICE);
	include 'sessioncontrol.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<?php 

require 'master.php';
if (!empty($_GET))
{
    if ($_GET['Logout'] && session_status() == PHP_SESSION_ACTIVE){
        unset($_SESSION['valid']);
        unset($_SESSION['timeout']);
        unset($_SESSION['id']);
        unset($_SESSION['name']);
        unset($_SESSION['username']);
        
        session_destroy();
        header('location:index.php');
    }
}
?>

	<div class="container text-center">
	<h1>Welcome to the Home page</h1>
	</div>

<?php require 'footer.php';?>
</body>
</html>