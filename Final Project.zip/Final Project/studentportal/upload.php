<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	if(isset($_POST["submit"])) {
	    $target_file = "uploads/" . $_FILES["fileToUpload"]["name"];
	if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
	    echo "The file ".  $target_file. " has been uploaded.";
	        } else {
	            echo "Sorry, there was an error uploading your file.";
	        }
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

<form action="upload.php" method="post" enctype="multipart/form-data">
  Select image to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload Image" name="submit">
</form>

<?php require 'footer.php';?>

</body>
</html>