<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	include 'sessioncontrol.php';
	require 'dbconn.php';
	require 'userservice.php';
	
	$userauth = New UserService($_SESSION['username'],0);
	$sendtoDB = New DBConn;
	// Build sql syntax
	$sqlselect=$userauth->userdataSQL($_SESSION['id']);
	$userdata = $sendtoDB->executeSelectQuery($sqlselect);

	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        table{
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Welcome to the Profile page</h1>
	</div>
	<br><br>
    <div class="table-responsive">
	<table class="table table-bordered" style="width:50%">
<?php
if (mysqli_num_rows($userdata)){
    $row = $userdata->fetch_assoc();
    echo "<tr><th class='text-center'>Field</th><th class='text-center'>Data</th></tr>";
    echo "<tr><td class='text-center'>Student ID:</td><td class='text-center'>" .$row['userid'] . "</td></tr>";
    echo "<tr><td class='text-center'>First Name:</td><td class='text-center'>" . $row['firstName'] . "</td></tr>";
    echo "<tr><td class='text-center'>Last Name:</td><td class='text-center'>" . $row['lastName'] . "</td></tr>";
    echo "<tr><td class='text-center'>Email:</td><td class='text-center'>" . $row['email'] . "</td></tr>";
    echo "<tr><td class='text-center'>Address:</td><td class='text-center'>" . $row['address'] . "</td></tr>";
    echo "<tr><td class='text-center'>City:</td><td class='text-center'>" . $row['city'] . "</td></tr>";
    echo "<tr><td class='text-center'>State:</td><td class='text-center'>" . $row['usstate'] . "</td></tr>";
    echo "<tr><td class='text-center'>zipcode:</td><td class='text-center'>" . $row['zipcode'] . "</td></tr>";
    echo "<tr><td class='text-center'>Mayor:</td><td class='text-center'>" . $row['mayor'] . "</td></tr>";

}
?>
	
	</table></div><br>
	<div class="text-center">
	<a class="btn btn-primary" href="index.php?Logout=1" role="button">Logout </a>
	</div><br><br><br>
<?php require 'footer.php';?>
</body>
</html>