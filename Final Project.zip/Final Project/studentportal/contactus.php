<?php
	error_reporting(E_ALL ^ E_NOTICE);
	include 'sessioncontrol.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Welcome to the Contact us page</h1>
	<address>
		<strong>XYZ company</strong><br>
		123 52th Ave<br>
		New York, NY 12345<br>
		<abbr title="Phone">P:</abbr> (123)456-7890
	</address>
	<address>
		<strong>Joe Smith</strong><br>
		<a href="mailto:#">Joe.Smith@xyzcompany.com</a>
	</address>
	</div>
<?php require 'footer.php';?>
</body>
</html>