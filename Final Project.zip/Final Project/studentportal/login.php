<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
    include 'sessioncontrol.php';
	require 'dbconn.php';
	require 'userservice.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php'; ?>

	<div class="container text-center">
	<h1>Welcome to the Login page</h1>
<?php 
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['email']) and !empty($_POST['pwd'])) {
        $userauth = New UserService($_POST['email'],$_POST['pwd']);
        $sendtoDB = New DBConn;
        // Build sql syntax
        $sqlselect=$userauth->loginSQL();
        $userdata = $sendtoDB->executeSelectQuery($sqlselect);
        
        if (mysqli_num_rows($userdata)){
            $row = $userdata->fetch_assoc();
            $_SESSION['valid'] = true;
            $_SESSION['id'] = $row['userid'];
            $_SESSION['name'] = $row['firstName'];
            $_SESSION['username'] = $userauth->getEmail();
            header("location:mainmenu.php"); //to redirect back to "index.php"
            exit();
        } else {
           echo "<h3><FONT COLOR='RED'>User or Password incorrect Try again</FONT></h3>";
        }
    }
}

?>
	<form class="form-horizontal" method="post" action="<?php echo $_SERVER["PHP_SELF"];?>">
		<div class="form-group">
			<label for="email">Email address:</label>
			<input type="email" class="form-control" placeholder="Email" id="email" name="email" required>
		</div>
		<div class="form-group">
			<label for="pwd">Password:</label>
			<input type="password" class="form-control" placeholder="Password" id="pwd" name="pwd" required>
		</div>
		<br>
		<div class="text-center">
			<button type="submit" class="btn btn-primary">Login</button></div>
		</form>
	</div>

<?php require 'footer.php';?>
</body>
</html>