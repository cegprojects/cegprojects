<?php
	error_reporting(E_ALL ^ E_NOTICE);
	
	include 'sessioncontrol.php';


	
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <style>
        table{
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Main Menu</h1>
	</div>
	<div class="text-center">
	<a class="btn btn-success" href="addcourse.php" role="button">Add Course </a>
	</div><br>
	<div class="text-center">
	<a class="btn btn-success" href="viewcourse.php" role="button">Current Courses </a>
	</div><br>
	<div class="text-center">
	<a class="btn btn-success" href="viewwl.php" role="button">Active Waiting List </a>
	</div><br>
	<br><br>
	<br><br>

	<div class="text-center">
	<a class="btn btn-primary" href="index.php?Logout=1" role="button">Logout </a>
	</div><br><br><br>
<?php require 'footer.php';?>
</body>
</html>