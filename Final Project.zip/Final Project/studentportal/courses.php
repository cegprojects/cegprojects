<?php

class courses {
    Private $course;    
    Private $semester;
    
    public function __construct()
    {
    }

    public function listcourses($semester)
    {
        $SQL = "SELECT tblcoursesemester.courseid, tblcoursesemester.maxstudents, tblcoursesemester.teacher,tblcourse.coursecode, tblcourse.credits, tblcourse.description FROM tblcoursesemester LEFT JOIN tblcourse ON tblcoursesemester.courseid=tblcourse.courseid WHERE semesterid='$semester'";
        return $SQL;
    }
    
    public function listsemester()
    {
        $SQL = "SELECT * FROM tblsemester";
        return $SQL;
    }
    public function checkcoursemax($course,$semester)
    {
        $SQL = "SELECT * FROM tblstudenthistory WHERE courseid='$course' AND semesterid='$semester'";
        return $SQL;
    }
    public function checkwlposition($course,$semester)
    {
        $SQL = "SELECT MAX(position) AS maxposition FROM tblwaitinglist WHERE courseid='$course' AND semesterid='$semester'";
        return $SQL;
    }
    public function checkcoursecurrent($course,$semester)
    {
        $SQL = "SELECT * FROM tblcoursesemester WHERE courseid='$course' AND semesterid='$semester'";
        return $SQL;
    }
    public function checkrepeatedenroll($student,$course,$semester)
    {
        $SQL = "SELECT * FROM tblstudenthistory WHERE studentid='$student' AND courseid='$course' AND semesterid='$semester'";
        return $SQL;
    }
    public function enrollcourse($student,$course,$semester)
    {
        $SQL = "INSERT INTO tblstudenthistory (`courseid`, `semesterid`, `studentid`) VALUES ('$course', '$semester', '$student')";
        return $SQL;
    }
     public function enrollwaitinglist($student,$course,$semester, $position)
    {
        $nextp = intval($position) + 1;
        $SQL = "INSERT INTO tblwaitinglist (`courseid`, `semesterid`, `studentid`, `position`) VALUES ('$course', '$semester', '$student', '$nextp')";
        return $SQL;
    }
    public function usercourses($id)
    {
        $SQL = "SELECT tblstudenthistory.shistoryid,tblcourse.coursecode, tblcourse.description, tblcourse.credits, tblsemester.semestercode FROM tblstudenthistory LEFT JOIN tblcourse ON tblstudenthistory.courseid=tblcourse.courseid LEFT JOIN tblsemester ON tblstudenthistory.semesterid=tblsemester.semesterid WHERE studentid='$id'";
        return $SQL;
    } 
    public function userwl($id)
    {
        $SQL = "SELECT tblwaitinglist.waitinglistid, tblwaitinglist.position, tblcourse.coursecode, tblcourse.description, tblcourse.credits, tblsemester.semestercode FROM tblwaitinglist LEFT JOIN tblcourse ON tblwaitinglist.courseid=tblcourse.courseid LEFT JOIN tblsemester ON tblwaitinglist.semesterid=tblsemester.semesterid WHERE studentid='$id'";
        return $SQL;
    } 
    public function removecourse($shistory)
    {
        $SQL = "DELETE FROM tblstudenthistory WHERE `tblstudenthistory`.`shistoryid` = '$shistory'";
        return $SQL;
    }
    public function removewl($waitinglistid)
    {
        $SQL = "DELETE FROM tblwaitinglist WHERE `tblwaitinglist`.`waitinglistid` = '$waitinglistid'";
        return $SQL;
    }
}

?>
