<?php
//Getting connection information for SQL server
require_once('config.php');

// Creating class for SQL transactions
Class DBConn{
	Private $conn;
	
	function __construct(){
		// Create connection
		$this->conn = mysqli_connect(DBHOST, DBUSER, DBPASS, DBNAME);
		// Check connection
		if (!$this->conn) {
			die("Connection failed: " . mysqli_connect_error());
		}
	}
	
	function __destruct(){
		mysqli_close($this->conn);	
	}
	
	function executeSelectQuery($sql){
		// execute query and return rows
		$result = mysqli_query($this->conn, $sql);
		return $result;
	}
	
	function executeQuery($sql){
		// execute query and check if it was successful
		if (mysqli_query($this->conn, $sql)) {
			//echo "New record created successfully";
			$status = 1;
		} 


		return $status;
	}
	
	function executeSelectBoolQuery($sql){
	    // execute query and check rows return
	    $rows = 0;
	    $result = mysqli_query($this->conn, $sql);
	    if (mysqli_num_rows($result)) {
	        $rows = 1;
	    }
	    
	    return $rows;
	}
}
?>
