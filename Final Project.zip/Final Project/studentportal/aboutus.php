<?php
	error_reporting(E_ALL ^ E_NOTICE);
	include 'sessioncontrol.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, inital-scale=1, maximun-scale=1"/>
	<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="scripts/jquery.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
</head>
<body>

<?php require 'master.php';?>

	<div class="container text-center">
	<h1>Welcome to the About us page</h1>
	</div>

<?php require 'footer.php';?>
</body>
</html>