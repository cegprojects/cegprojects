<?php

class userservice {
    Private $email;    
    Private $password;
    
    public function __construct($email, $password)
    {
        $this->setEmail($email);
        $this->setPassword($password);
    }
    
    // Get function
    public function getEmail() {
        return $this->email;
    }
    public function getPassword() {
        return $this->password;
    }
    
    // Set fucntion
    public function setEmail ($email) {
        $this->email = $email;
    }
    public function setPassword ($password) {
        $this->password = $password;
    }

    
    public function loginSQL()
    {
        $SQL = "SELECT userid, firstName FROM tbluser WHERE email='$this->email' AND password='$this->password'";
        return $SQL;
    }
    
    public function userdataSQL($id)
    {
        $SQL = "SELECT * FROM tbluser WHERE userid='$id'";
        return $SQL;
    }
    public function userACLSQL($id)
    {
        $SQL = "SELECT * FROM tblacl WHERE userid='$id'";
        return $SQL;
    }
    Public function logout(){
        session_destroy(); //destroy the session
        header("location:/index.php"); //to redirect back to "index.php" after logging out
        exit();
    }
    
}

?>
